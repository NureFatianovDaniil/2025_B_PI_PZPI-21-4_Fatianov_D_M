package com.fatia.Auth.UserService.entities;

public enum Role {
    ADMIN,
    MANAGER,
    WORKER
}
