package com.fatia.warehouseservice.entities.graph;

public enum NodeType {
    ENTRY_NODE,
    DEFAULT
}
