package com.fatia.warehouseservice.entities.graph;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Property;
import org.springframework.data.neo4j.core.schema.Relationship;

import java.util.ArrayList;
import java.util.List;

@org.springframework.data.neo4j.core.schema.Node("Node")
@Data
public class NodeEntity {
    @Id
    @GeneratedValue
    private Long id;

    @Property("zoneId")
    private Long zoneId;

    @Property("x")
    private int X;

    @Property("y")
    private int Y;

    @Property("type")
    private String type;

    @Relationship(type = "CONNECTED_TO", direction = Relationship.Direction.OUTGOING)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private List<EdgeEntity> edges = new ArrayList<>();
}
