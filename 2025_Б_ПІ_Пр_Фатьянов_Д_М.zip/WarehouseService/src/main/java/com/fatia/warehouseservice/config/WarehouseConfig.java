package com.fatia.warehouseservice.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "warehouse")
@Getter
@Setter
public class WarehouseConfig {
    private int width;
    private int length;
    private int originX;
    private int originY;

    private boolean allowPeripheralPaths; // Дозволити створення маршрутів навколо STORAGE-зон
    private int peripheralPathOffset; // Відступ між зоною та дорогою навколо (в клітинках)
    private boolean allowBidirectionalPaths; // Чи дозволені двосторонні ребра
    private boolean autoTurnNodePlacement;// Автоматично створювати поворотні вузли між parent-child
    private int edgeDefaultWeight; // Вага ребра за замовчуванням
    private int entryNodeParentZoneOffset;// Відстань від лицевої сторони батьківської зони до entryNode
    private int entryNodeChildZoneOffset;// Відстань від лицевої сторони дочірньої зони до entryNode
    private int edgeWidth;
}
