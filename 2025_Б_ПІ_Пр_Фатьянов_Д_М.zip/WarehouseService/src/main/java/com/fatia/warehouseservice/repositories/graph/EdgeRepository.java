package com.fatia.warehouseservice.repositories.graph;

import com.fatia.warehouseservice.entities.graph.EdgeEntity;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface EdgeRepository extends Neo4jRepository<EdgeEntity, Long> {
}
