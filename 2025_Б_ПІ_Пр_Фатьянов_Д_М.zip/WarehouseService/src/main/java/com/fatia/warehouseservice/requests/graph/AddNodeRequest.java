package com.fatia.warehouseservice.requests.graph;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddNodeRequest {
    private Long zoneId;
    private int X;
    private int Y;
    private String type;
}
