package com.fatia.warehouseservice.repositories.graph;

import com.fatia.warehouseservice.entities.graph.NodeEntity;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface NodeRepository extends Neo4jRepository<NodeEntity, Long> {
}
