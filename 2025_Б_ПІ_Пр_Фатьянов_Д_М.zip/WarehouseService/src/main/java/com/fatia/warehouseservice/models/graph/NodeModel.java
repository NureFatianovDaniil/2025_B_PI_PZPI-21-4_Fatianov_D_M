package com.fatia.warehouseservice.models.graph;

import com.fatia.warehouseservice.entities.graph.NodeEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NodeModel {
    private Long id;
    private Long zoneId;
    private int X;
    private int Y;
    private String type;
    private List<EdgeModel> edges = new ArrayList<>();

    public static NodeModel toModel(NodeEntity nodeEntity) {
        return NodeModel
                .builder()
                .id(nodeEntity.getId())
                .zoneId(nodeEntity.getZoneId())
                .X(nodeEntity.getX())
                .Y(nodeEntity.getY())
                .type(nodeEntity.getType())
                .edges(
                        nodeEntity.getEdges()
                                .stream()
                                .map(EdgeModel::toModel)
                                .collect(Collectors.toList())
                )
                .build();
    }
}
