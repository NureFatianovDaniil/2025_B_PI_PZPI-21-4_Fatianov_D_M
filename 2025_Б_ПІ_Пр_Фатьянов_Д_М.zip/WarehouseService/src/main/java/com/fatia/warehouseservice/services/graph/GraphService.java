package com.fatia.warehouseservice.services.graph;

import com.fatia.warehouseservice.config.WarehouseConfig;
import com.fatia.warehouseservice.entities.ZoneEntity;
import com.fatia.warehouseservice.entities.graph.EdgeEntity;
import com.fatia.warehouseservice.entities.graph.NodeEntity;
import com.fatia.warehouseservice.models.graph.EdgeModel;
import com.fatia.warehouseservice.models.graph.NodeModel;
import com.fatia.warehouseservice.repositories.ZoneRepository;
import com.fatia.warehouseservice.repositories.graph.EdgeRepository;
import com.fatia.warehouseservice.repositories.graph.NodeRepository;
import com.fatia.warehouseservice.requests.graph.AddNodeRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class GraphService {

    private final NodeRepository nodeRepository;

    private final EdgeRepository edgeRepository;

    private final ZoneRepository zoneRepository;

    private final WarehouseConfig warehouseConfig;

    public void updateGraphWithZone(ZoneEntity zoneEntity) {
        switch (zoneEntity.getType()) {
            case STORAGE:
                handleStorageZone(zoneEntity);
                break;
            case COLUMN:
                handleColumnZone(zoneEntity);
                break;
            case PARKING:
                handleParkingZone(zoneEntity);
                break;
            case PARKING_SPOT:
                handleParkingSpotZone(zoneEntity);
                break;
            case UNLOADING:
                handleUnloadingZone(zoneEntity);
                break;
            case LOADING:
                handleLoadingZone(zoneEntity);
                break;
            default:
                break;
        }
    }

    private void handleLoadingZone(ZoneEntity zone) {
        int zoneRoadGap = warehouseConfig.getPeripheralPathOffset();
        int warehouseWidth = warehouseConfig.getWidth();
        int warehouseHeight = warehouseConfig.getLength();
        int roadWidth = warehouseConfig.getEdgeWidth();

        int zoneWidth = (zone.getRotationAngle() % 180 == 0)
                ? zone.getWidth() : zone.getLength();
        int zoneHeight = (zone.getRotationAngle() % 180 == 0)
                ? zone.getLength() : zone.getWidth();

    }

    public void handleStorageZone(ZoneEntity zone) {
        int zoneRoadGap = warehouseConfig.getPeripheralPathOffset();
        int warehouseWidth = warehouseConfig.getWidth();
        int warehouseHeight = warehouseConfig.getLength();
        int roadWidth = warehouseConfig.getEdgeWidth();

        int zoneWidth = (zone.getRotationAngle() % 180 == 0)
                ? zone.getWidth() : zone.getLength();
        int zoneHeight = (zone.getRotationAngle() % 180 == 0)
                ? zone.getLength() : zone.getWidth();

        // Обчислення меж дороги
        int roadLeft = zone.getOriginX() - zoneRoadGap - roadWidth;
        int roadTop = zone.getOriginY() - zoneRoadGap - roadWidth;
        int roadRight = zone.getOriginX() + zoneWidth + zoneRoadGap + roadWidth;
        int roadBottom = zone.getOriginY() + zoneHeight + zoneRoadGap + roadWidth;

        // Для перевірки чи не перетинаються Зони доріг з іншими зонами
        int leftZoneX1 = roadLeft;
        int leftZoneY1 = zone.getOriginY() - zoneRoadGap;
        int leftZoneX2 = roadLeft + roadWidth + zoneRoadGap;
        int leftZoneY2 = zone.getOriginY() + zoneHeight + zoneRoadGap;

        int rightZoneX1 = roadRight - roadWidth - zoneRoadGap;
        int rightZoneY1 = zone.getOriginY() - zoneRoadGap;
        int rightZoneX2 = roadRight;
        int rightZoneY2 = zone.getOriginY() + zoneHeight + zoneRoadGap;

        int topZoneX1 = zone.getOriginX() - zoneRoadGap;
        int topZoneY1 = roadTop;
        int topZoneX2 = zone.getOriginX() + zoneWidth + zoneRoadGap;
        int topZoneY2 = roadTop + roadWidth + zoneRoadGap;

        int bottomZoneX1 = zone.getOriginX() - zoneRoadGap;
        int bottomZoneY1 = roadBottom - roadWidth - zoneRoadGap;
        int bottomZoneX2 = zone.getOriginX() + zoneWidth + zoneRoadGap;
        int bottomZoneY2 = roadBottom;

        List<ZoneEntity> zones = zoneRepository.findAll();
        List<NodeEntity> nodes = nodeRepository.findAll();
        List<EdgeEntity> edges = edgeRepository.findAll();

        boolean canBuildLeft = isRoadSideFree(
                leftZoneX1, leftZoneY1, leftZoneX2, leftZoneY2,
                zones, nodes, edges
        );

        boolean canBuildRight = isRoadSideFree(
                rightZoneX1, rightZoneY1, rightZoneX2, rightZoneY2,
                zones, nodes, edges
        );

        boolean canBuildTop = isRoadSideFree(
                topZoneX1, topZoneY1, topZoneX2, topZoneY2,
                zones, nodes, edges
        );

        boolean canBuildBottom = isRoadSideFree(
                bottomZoneX1, bottomZoneY1, bottomZoneX2, bottomZoneY2,
                zones, nodes, edges
        );

        // Якщо дорога виходить за ліву межу складу,
        // лівий край дороги у originX - zoneRoadGap
        if (roadLeft <= 0 && canBuildLeft) {
            roadLeft = zone.getOriginX() - zoneRoadGap;
            canBuildLeft = false;
        }

        // Якщо дорога виходить за верхню межу складу,
        // верхній край дороги у originY - zoneRoadGap
        if (roadTop <= 0 && canBuildTop) {
            roadTop = zone.getOriginY() - zoneRoadGap;
            canBuildTop = false;
        }

        // Якщо дорога виходить за праву межу складу,
        // правий край дороги у originX + zoneWidth + zoneRoadGap
        if (roadRight >= warehouseWidth && canBuildRight) {
            roadRight = zone.getOriginX() + zoneWidth + zoneRoadGap;
            canBuildRight = false;
        }

        // Якщо дорога виходить за нижню межу складу,
        // нижній край дороги у originY + zoneHeight + zoneRoadGap
        if (roadBottom >= warehouseHeight && canBuildBottom) {
            roadBottom = zone.getOriginY() + zoneHeight + zoneRoadGap;
            canBuildBottom = false;
        }

        int roadX = roadLeft;
        int roadY = roadTop;
        int roadLength = roadRight - roadLeft;
        int roadHeight = roadBottom - roadTop;

        Point topLeft = new Point(
                roadLeft - roadWidth / 2,
                roadTop - roadWidth / 2);
        Point topRight = new Point(
                roadRight - roadWidth / 2,
                roadTop - roadWidth / 2);
        Point bottomRight = new Point(
                roadRight - roadWidth / 2,
                roadBottom - roadWidth / 2);
        Point bottomLeft = new Point(
                roadLeft - roadWidth / 2,
                roadBottom - roadWidth / 2);

        // Створення вузлів
        NodeEntity nodeTopLeft = createNode(zone.getId(), topLeft, "DEFAULT");
        NodeEntity nodeTopRight = createNode(zone.getId(), topRight, "DEFAULT");
        NodeEntity nodeBottomRight = createNode(zone.getId(), bottomRight, "DEFAULT");
        NodeEntity nodeBottomLeft = createNode(zone.getId(), bottomLeft, "DEFAULT");

        // Зʼєднання вузлів
        connectNodes(nodeTopLeft, nodeTopRight, roadWidth);
        connectNodes(nodeTopRight, nodeBottomRight, roadWidth);
        connectNodes(nodeBottomRight, nodeBottomLeft, roadWidth);
        connectNodes(nodeBottomLeft, nodeTopLeft, roadWidth);

    }

    // Метод створення вузла
    private NodeEntity createNode(Long zoneId, Point p, String type) {
        NodeEntity node = new NodeEntity();
        node.setZoneId(zoneId);
        node.setX(p.x);
        node.setY(p.y);
        node.setType(type);
        return nodeRepository.save(node);
    }

    // Метод з'єднання вузлів
    private void connectNodes(NodeEntity from, NodeEntity to, int width) {
        EdgeEntity edge = new EdgeEntity();
        edge.setTargetNode(to);
        edge.setBidirectional(false);
        edge.setDistance(calculateDistance(from, to));
        edge.setAngle(calculateAngle(from, to));
        edge.setWidth(width);
        if (from.getEdges() == null) {
            from.setEdges(new ArrayList<>());
        }
        from.getEdges().add(edge);
        nodeRepository.save(from);
    }

    private int calculateDistance(NodeEntity from, NodeEntity to) {
        return Math.abs(from.getX() - to.getX()) + Math.abs(from.getY() - to.getY());
    }

    // Обчислення кута повороту
    private int calculateAngle(NodeEntity from, NodeEntity to) {
        double angle = Math.toDegrees(Math.atan2(to.getY() - from.getY(), to.getX() - from.getX()));
        return (int) ((angle + 360) % 360);
    }

    private boolean isRoadSideFree(int x1, int y1, int x2, int y2,
                                   List<ZoneEntity> zones,
                                   List<NodeEntity> nodes,
                                   List<EdgeEntity> edges) {

        // Перевірка перетину з іншими зонами
        for (ZoneEntity other : zones) {
            int otherX1 = other.getOriginX();
            int otherY1 = other.getOriginY();
            int otherX2 = otherX1 + ((other.getRotationAngle() % 180 == 0) ? other.getWidth() : other.getLength());
            int otherY2 = otherY1 + ((other.getRotationAngle() % 180 == 0) ? other.getLength() : other.getWidth());

            if (intersects(x1, y1, x2, y2, otherX1, otherY1, otherX2, otherY2)) {
                return false;
            }
        }

        // Перевірка перетину з вузлами
        for (NodeEntity node : nodes) {
            int nodeX = node.getX();
            int nodeY = node.getY();
            if (nodeX >= x1 && nodeX <= x2 && nodeY >= y1 && nodeY <= y2) {
                return false;
            }
        }

        Map<Long, Point> nodePositionsMap = new HashMap<>();

        for (NodeEntity node : nodes) {
            nodePositionsMap.put(node.getId(), new Point(node.getX(), node.getY()));
        }

        // Перевірка перетину з ребрами
        for (EdgeEntity edge : edges) {
            NodeEntity fromNode = null;
            for (NodeEntity node : nodes) {
                if (node.getEdges() != null && node.getEdges().contains(edge)) {
                    fromNode = node;
                    break;
                }
            }
            if (fromNode == null) {
                continue;
            }

            NodeEntity toNode = edge.getTargetNode();
            if (toNode == null) {
                continue;
            }

            int minX = Math.min(fromNode.getX(), toNode.getX());
            int maxX = Math.max(fromNode.getX(), toNode.getX());
            int minY = Math.min(fromNode.getY(), toNode.getY());
            int maxY = Math.max(fromNode.getY(), toNode.getY());

            if (intersects(x1, y1, x2, y2, minX, minY, maxX, maxY)) {
                return false;
            }
        }

        return true;
    }

    private boolean intersects(int ax1, int ay1, int ax2, int ay2,
                               int bx1, int by1, int bx2, int by2) {
        return ax1 < bx2 && ax2 > bx1 && ay1 < by2 && ay2 > by1;
    }

    public List<NodeModel> getAllNodes() {
        List<NodeEntity> nodeEntities = nodeRepository.findAll();
        List<NodeModel> nodeModels = new ArrayList<>();
        for (NodeEntity nodeEntity : nodeEntities) {
            nodeModels.add(NodeModel.toModel(nodeEntity));
        }
        return nodeModels;
    }

    public List<EdgeModel> getAllEdges() {
        List<EdgeEntity> edgeEntities = edgeRepository.findAll();
        List<EdgeModel> edgeModels = new ArrayList<>();
        for (EdgeEntity edgeEntity : edgeEntities) {
            edgeModels.add(EdgeModel.toModel(edgeEntity));
        }
        return edgeModels;
    }

    public void deleteAllNodes() {
        List<NodeEntity> nodeEntities = nodeRepository.findAll();
        nodeRepository.deleteAll(nodeEntities);
    }

    public void deleteAllEdges() {
        List<EdgeEntity> edgeEntities = edgeRepository.findAll();
        edgeRepository.deleteAll(edgeEntities);
    }

    public ResponseEntity<NodeModel> addNode(AddNodeRequest request) {
        Optional<ZoneEntity> optionalZone = zoneRepository.findById(request.getZoneId());
        if (optionalZone.isEmpty()) {
            throw new RuntimeException("Zone with ID" + request.getZoneId() + "not found");
        }

        NodeEntity nodeEntity = new NodeEntity();
        nodeEntity.setX(request.getX());
        nodeEntity.setY(request.getY());
        nodeEntity.setType(request.getType());

        nodeEntity = nodeRepository.save(nodeEntity);

        return ResponseEntity.ok(NodeModel.toModel(nodeEntity));
    }

    public NodeModel connectNodes(Long fromId, Long toId) {
        Optional<NodeEntity> optionalFromEntity = nodeRepository.findById(fromId);
        if (optionalFromEntity.isEmpty()) {
            throw new RuntimeException("Node with ID" + fromId + "not found");
        }

        Optional<NodeEntity> optionalToEntity = nodeRepository.findById(toId);
        if (optionalToEntity.isEmpty()) {
            throw new RuntimeException("Node with ID" + toId + "not found");
        }

        connectNodes(
                optionalFromEntity.get(),
                optionalToEntity.get(),
                warehouseConfig.getEdgeWidth()
        );

        NodeEntity node = nodeRepository.findById(fromId).get();
        return NodeModel.toModel(node);
    }

    private void handleUnloadingZone(ZoneEntity zone) {

    }

    private void handleParkingSpotZone(ZoneEntity zone) {

    }

    private void handleParkingZone(ZoneEntity zone) {

    }

    private void handleColumnZone(ZoneEntity zone) {
    }

    private class Point {
        int x;
        int y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}
