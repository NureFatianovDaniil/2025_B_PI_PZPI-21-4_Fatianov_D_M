package com.fatia.warehouseservice.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "shelves")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class ShelfEntity {
    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "zone_id", nullable = false)
    private ZoneEntity zone;// COLUMN zone

    private int width;

    private int length;

    private int height;

    private int level;

    private String description;

    private boolean isOccupied;

    private boolean isActive;
}
