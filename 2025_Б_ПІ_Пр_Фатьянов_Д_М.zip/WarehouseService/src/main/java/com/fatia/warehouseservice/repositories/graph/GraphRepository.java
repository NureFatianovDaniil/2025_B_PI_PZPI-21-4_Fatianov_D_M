package com.fatia.warehouseservice.repositories.graph;

public interface GraphRepository {
}
