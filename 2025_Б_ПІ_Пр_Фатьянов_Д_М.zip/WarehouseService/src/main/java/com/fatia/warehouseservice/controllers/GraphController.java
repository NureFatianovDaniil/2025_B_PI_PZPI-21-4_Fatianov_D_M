package com.fatia.warehouseservice.controllers;

import com.fatia.warehouseservice.models.graph.EdgeModel;
import com.fatia.warehouseservice.models.graph.NodeModel;
import com.fatia.warehouseservice.requests.graph.AddNodeRequest;
import com.fatia.warehouseservice.services.graph.GraphService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController("/api/v1/graph")
@RequiredArgsConstructor
public class GraphController {

    private final GraphService graphService;

    @GetMapping("/get-all-nodes")
    public ResponseEntity<List<NodeModel>> getAllNodes() {
        return ResponseEntity.ok(graphService.getAllNodes());
    }

    @GetMapping("/get-all-edges")
    public ResponseEntity<List<EdgeModel>> getAllEdges() {
        return ResponseEntity.ok(graphService.getAllEdges());
    }

    @DeleteMapping("/delete-all-nodes")
    public ResponseEntity<String> deleteAllNodes() {
        graphService.deleteAllNodes();
        return ResponseEntity.ok("Nodes was deleted");
    }

    @DeleteMapping("/delete-all-edges")
    public ResponseEntity<String> deleteAllEdges() {
        graphService.deleteAllEdges();
        return ResponseEntity.ok("Edges was deleted");
    }

    @PostMapping("/add-node")
    public ResponseEntity<NodeModel> addNode(
            @RequestBody AddNodeRequest request
    ) {
        return graphService.addNode(request);
    }

    @PostMapping("/connect-nodes/{fromId}/{toId}")
    public ResponseEntity<NodeModel> connectNode(
            @PathVariable Long fromId,
            @PathVariable Long toId
    ) {
        return ResponseEntity.ok(graphService.connectNodes(fromId, toId));
    }
}
