package com.fatia.warehouseservice.models.graph;

import com.fatia.warehouseservice.entities.graph.EdgeEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EdgeModel {
    private Long id;
    private Long toId;
    private Integer distance;
    private Integer angle;
    private Integer width;
    private boolean bidirectional;

    public static EdgeModel toModel(EdgeEntity edgeEntity) {
        return EdgeModel
                .builder()
                .id(edgeEntity.getId())
                .toId(edgeEntity.getTargetNode().getId())
                .distance(edgeEntity.getDistance())
                .angle(edgeEntity.getAngle())
                .width(edgeEntity.getWidth())
                .bidirectional(edgeEntity.isBidirectional())
                .build();
    }
}
