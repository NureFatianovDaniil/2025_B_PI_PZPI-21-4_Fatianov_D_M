package com.fatia.warehouseservice.entities.graph;

import lombok.Data;
import org.springframework.data.neo4j.core.schema.*;

@RelationshipProperties
@Data
public class EdgeEntity {
    @Id
    @GeneratedValue
    private Long id;

    @TargetNode
    private NodeEntity targetNode;

    @Property("distance")
    private Integer distance;

    @Property("angle")
    private Integer angle;

    @Property("width")
    private Integer width;

    @Property("bidirectional")
    private boolean bidirectional;

}
