package com.fatia.inventoryservice;

import jakarta.transaction.Transactional;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Transactional
public class SKUServiceTests {
}
