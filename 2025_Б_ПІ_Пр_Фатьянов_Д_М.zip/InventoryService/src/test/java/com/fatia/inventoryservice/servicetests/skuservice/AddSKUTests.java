package com.fatia.inventoryservice.servicetests.skuservice;

import com.fatia.inventoryservice.inventoryentities.SKUEntity;
import com.fatia.inventoryservice.inventoryentities.SKUStatus;
import com.fatia.inventoryservice.inverntoryrepositories.SKURepository;
import com.fatia.inventoryservice.models.SKUModel;
import com.fatia.inventoryservice.requests.AddSKURequest;
import com.fatia.inventoryservice.services.SKUService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
@RequiredArgsConstructor
public class AddSKUTests {

    @Autowired
    private SKUService skuService;

    @Autowired
    private SKURepository skuRepository;

    // Тестуємо додавання нового SKU з batch "001"
    @Test
    void whenAddSKU_thenSaveAndReturnSKUModel_withBatch001() {
        // Підготовка вхідного запиту
        AddSKURequest request = new AddSKURequest();
        request.setName("Test Product \"SKU\"");
        request.setCode("TESTCODE123");
        request.setDescription("Test description");
        request.setLength(10);
        request.setWidth(5);
        request.setHeight(2);
        request.setQuantity(100);
        request.setStorageConditions(Map.of("TEMPERATURE", "5-10C"));

        // Виклик методу додавання
        SKUModel skuModel = skuService.addSKU(request);

        // Перевірка, що SKU збережений у базі
        SKUEntity savedEntity = skuRepository.findById(skuModel.getId()).orElseThrow();

        // Перевірка правильності збережених полів
        assertEquals("TESTCODE123", savedEntity.getCode());
        assertEquals("Test description", savedEntity.getDescription());
        assertEquals(SKUStatus.CREATED, savedEntity.getStatus());
        assertEquals(10, savedEntity.getLength());
        assertEquals(5, savedEntity.getWidth());
        assertEquals(2, savedEntity.getHeight());
        assertEquals(100, savedEntity.getQuantity());
        assertEquals("001", savedEntity.getBatch()); // перший batch має бути 001
        assertNotNull(savedEntity.getCreatedAt());

        // Перевірка коректності SKUModel, який повертається методом
        assertEquals(savedEntity.getId(), skuModel.getId());
        assertEquals(savedEntity.getCode(), skuModel.getCode());
    }
}
