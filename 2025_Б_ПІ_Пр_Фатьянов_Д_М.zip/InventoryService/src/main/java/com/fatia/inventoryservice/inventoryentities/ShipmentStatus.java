package com.fatia.inventoryservice.inventoryentities;

public enum ShipmentStatus {
    CREATED,
    UPDATED,
    PICKING,
    DELIVERED,
    SHIPPED
}
