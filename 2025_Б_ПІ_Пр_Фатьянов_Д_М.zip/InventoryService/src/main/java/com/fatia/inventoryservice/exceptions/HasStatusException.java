package com.fatia.inventoryservice.exceptions;

public class HasStatusException extends RuntimeException {
    public HasStatusException(String message) {
        super(message);
    }
}
