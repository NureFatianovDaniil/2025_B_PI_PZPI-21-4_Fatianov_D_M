package config

type WarehouseGraphConfig struct {
	AllowPeripheralPaths      bool // Дозволити створення маршрутів навколо STORAGE-зон
	PeripheralPathOffset      int  // Відступ між зоною та дорогою навколо (в клітинках)
	AllowBidirectionalEdges   bool // Чи дозволені двосторонні ребра
	AutoTurnNodePlacement     bool // Автоматично створювати поворотні вузли між parent-child
	EdgeDefaultWeight         int  // Вага ребра за замовчуванням
	AllowDiagonalConnections  bool // Чи дозволені діагональні з'єднання (можна потім)
	AllowStorageColumnLinks   bool // Дозволити прямі з'єднання між колонками зони STORAGE
	EntryNodeParentZoneOffset int  // Відстань від лицевої сторони батьківської зони до entryNode
	EntryNodeChildZoneOffset  int  // Відстань від лицевої сторони дочірньої зони до entryNode
}

func NewWarehouseGraphConfig() *WarehouseGraphConfig {
	return &WarehouseGraphConfig{
		AllowPeripheralPaths:      true,
		PeripheralPathOffset:      50,
		AllowBidirectionalEdges:   true,
		AutoTurnNodePlacement:     true,
		EdgeDefaultWeight:         100,
		AllowDiagonalConnections:  false,
		AllowStorageColumnLinks:   false,
		EntryNodeParentZoneOffset: 15,
		EntryNodeChildZoneOffset:  0,
	}
}
