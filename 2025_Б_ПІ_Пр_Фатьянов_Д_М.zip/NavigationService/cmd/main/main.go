package main

import (
	"fmt"
	"github.com/FatiaGlacier/navigation-service/cmd/config"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/api"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/db"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/repository"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/router"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/service"
	"github.com/gin-gonic/gin"
)

func main() {
	config.LoadEnv()
	
	//warehouse config
	config.NewWarehouseGraphConfig()

	db.InitPostgresDB()
	fmt.Println("Connected to PostgreSQL")

	db.InitNeo4j()
	fmt.Println("Connected to Neo4j")

	// Репозиторії
	nodeRepo := repository.NewNodeRepository(db.Neo4JDriver)
	edgeRepo := repository.NewEdgeRepository(db.Neo4JDriver)
	graphRepo := repository.NewGraphRepository(db.Neo4JDriver)
	fmt.Println("Repos")

	// Сервіси
	nodeService := service.NewNodeService(nodeRepo, edgeRepo)
	edgeService := service.NewEdgeService(edgeRepo, nodeRepo)
	graphService := service.NewGraphService(graphRepo, edgeRepo, nodeRepo)
	fmt.Println("Services")

	// Хендлери
	nodeHandler := api.NewNodeHandler(nodeService)
	edgeHandler := api.NewEdgeHandler(edgeService)
	graphHandler := api.NewGraphHandler(graphService)
	fmt.Println("Handlers")

	// Роутер
	r := gin.Default()

	// Реєстрація маршрутів із передачею хендлерів
	router.RegisterRoutes(r, nodeHandler, edgeHandler, graphHandler)

	err := r.Run()
	if err != nil {
		return
	}
}
