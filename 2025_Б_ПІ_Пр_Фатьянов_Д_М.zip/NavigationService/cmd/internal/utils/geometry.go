package utils

type Point struct {
	X int
	Y int
}

func CalculateEntryNodePosition(originX, originY, width, length, faceDirection, offset int) Point {
	var centerX, centerY int

	switch faceDirection {
	case 0: // вгору
		centerX = originX + width/2
		centerY = originY
		centerY -= offset
	case 90: // вправо
		centerX = originX + width
		centerY = originY + length/2
		centerX += offset
	case 180: // вниз
		centerX = originX + width/2
		centerY = originY + length
		centerY += offset
	case 270: // вліво
		centerX = originX
		centerY = originY + length/2
		centerX -= offset
	default:
		// на випадок помилки в faceDirection, можна кинути panic або поставити дефолт
		centerX = originX + width/2
		centerY = originY
	}

	return Point{X: centerX, Y: centerY}
}
