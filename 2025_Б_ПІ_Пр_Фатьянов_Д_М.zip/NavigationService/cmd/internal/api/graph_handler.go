package api

import (
	"github.com/FatiaGlacier/navigation-service/cmd/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type GraphHandler struct {
	graphService *service.GraphService
}

func NewGraphHandler(
	graphService *service.GraphService) *GraphHandler {
	return &GraphHandler{
		graphService: graphService,
	}
}

func (h *GraphHandler) UpdateGraph(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "UpdateGraph called"})
}

func (h *GraphHandler) GetRouteWaveless(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "GetRouteWaveless called"})
}

func (h *GraphHandler) GetRouteWavebased(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "GetRouteWavebased called"})
}
