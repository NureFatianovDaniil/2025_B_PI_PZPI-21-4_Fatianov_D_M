package api

import (
	"github.com/FatiaGlacier/navigation-service/cmd/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type EdgeHandler struct {
	edgeService *service.EdgeService
}

func NewEdgeHandler(
	edgeService *service.EdgeService) *EdgeHandler {
	return &EdgeHandler{
		edgeService: edgeService,
	}
}

func (h *EdgeHandler) GetAllEdges(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "GetAllEdges called"})
}

func (h *EdgeHandler) GetEdgeByID(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "GetEdgeByID called", "id": id})
}

func (h *EdgeHandler) AddEdge(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "AddEdge called"})
}

func (h *EdgeHandler) UpdateEdge(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "UpdateEdge called", "id": id})
}

func (h *EdgeHandler) DeleteEdge(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "DeleteEdge called", "id": id})
}
