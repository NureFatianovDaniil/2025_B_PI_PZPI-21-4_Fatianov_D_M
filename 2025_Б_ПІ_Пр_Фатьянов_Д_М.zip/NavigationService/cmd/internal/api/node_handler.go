package api

import (
	"github.com/FatiaGlacier/navigation-service/cmd/internal/model/dto"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type NodeHandler struct {
	nodeService *service.NodeService
}

func NewNodeHandler(
	nodeService *service.NodeService) *NodeHandler {
	return &NodeHandler{
		nodeService: nodeService,
	}
}

func (h *NodeHandler) CreateEntryNodeFromZone(c *gin.Context) {
	var zone dto.ZoneModel

	if err := c.ShouldBindJSON(&zone); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body", "details": err.Error()})
		return
	}

	// Валідація
	if zone.Width <= 0 || zone.Length <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Zone width and length must be greater than zero"})
		return
	}

	if zone.FaceDirection != 0 && zone.FaceDirection != 90 && zone.FaceDirection != 180 && zone.FaceDirection != 270 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "FaceDirection must be one of 0, 90, 180, 270"})
		return
	}

	// TODO: виклик сервісу створення вузлів
	c.JSON(http.StatusOK, gin.H{"message": "Validated successfully, ready for processing"})
}

func (h *NodeHandler) GetAllNodes(c *gin.Context) {
	// тимчасово повертаємо заглушку
	c.JSON(http.StatusOK, gin.H{"message": "GetAllNodes called"})
}

func (h *NodeHandler) GetNodeByID(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "GetNodeByID called", "id": id})
}

func (h *NodeHandler) AddNode(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "AddNode called"})
}

func (h *NodeHandler) ConnectNodes(c *gin.Context) {
	fromId := c.Param("fromId")
	toId := c.Param("toId")
	c.JSON(http.StatusOK, gin.H{"message": "ConnectNodes called", "fromId": fromId, "toId": toId})
}

func (h *NodeHandler) UpdateNode(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "UpdateNode called", "id": id})
}

func (h *NodeHandler) DeleteNode(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{"message": "DeleteNode called", "id": id})
}
