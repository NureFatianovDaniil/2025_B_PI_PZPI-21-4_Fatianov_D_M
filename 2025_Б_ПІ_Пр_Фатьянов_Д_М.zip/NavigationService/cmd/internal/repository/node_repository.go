package repository

import (
	"context"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/model/entity"
	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
)

type NodeRepository struct {
	driver neo4j.DriverWithContext
}

func NewNodeRepository(driver neo4j.DriverWithContext) *NodeRepository {
	return &NodeRepository{driver: driver}
}

func (r *NodeRepository) CreateNode(ctx context.Context, node entity.NodeEntity) error {
	session := r.driver.NewSession(ctx, neo4j.SessionConfig{AccessMode: neo4j.AccessModeWrite})
	defer session.Close(ctx)

	_, err := session.ExecuteWrite(ctx, func(tx neo4j.Transaction) (interface{}, error) {
		query := `
			CREATE (n:Node {
				zoneId: $zoneId,
				x: $x,
				y: $y,
				type: $type
			})`
		params := map[string]interface{}{
			"zoneId": node.ZoneId,
			"x":      node.X,
			"y":      node.Y,
			"type":   node.NodeType,
		}
		result, err := tx.Run(ctx, query, params)
		return result, err
	})

	return err
}
