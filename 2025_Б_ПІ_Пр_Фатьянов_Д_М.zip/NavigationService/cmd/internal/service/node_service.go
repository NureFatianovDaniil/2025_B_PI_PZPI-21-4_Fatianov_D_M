package service

import (
	"github.com/FatiaGlacier/navigation-service/cmd/config"
	"github.com/FatiaGlacier/navigation-service/cmd/internal/repository"
)

type NodeService struct {
	nodeRepository       *repository.NodeRepository
	edgeRepository       *repository.EdgeRepository
	warehouseGraphConfig *config.WarehouseGraphConfig
}

func NewNodeService(
	nodeRepository *repository.NodeRepository,
	edgeRepository *repository.EdgeRepository,
	warehouseGraphConfig *config.WarehouseGraphConfig) *NodeService {
	return &NodeService{
		nodeRepository:       nodeRepository,
		edgeRepository:       edgeRepository,
		warehouseGraphConfig: warehouseGraphConfig,
	}
}

type Point struct {
	X int
	Y int
}

type Zone struct {
	ID            int64
	Type          string
	OriginX       int
	OriginY       int
	Width         int
	Length        int
	RotationAngle int
	FaceDirection int
	ChildZones    []Zone
}

func (s *NodeService) AddEntryNodeForZone  {

}
