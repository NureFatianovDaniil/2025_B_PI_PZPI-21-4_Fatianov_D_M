package service

import "github.com/FatiaGlacier/navigation-service/cmd/internal/repository"

type EdgeService struct {
	edgeRepository *repository.EdgeRepository
	nodeRepository *repository.NodeRepository
}

func NewEdgeService(
	edgeRepository *repository.EdgeRepository,
	nodeRepository *repository.NodeRepository) *EdgeService {
	return &EdgeService{
		edgeRepository: edgeRepository,
		nodeRepository: nodeRepository,
	}
}
