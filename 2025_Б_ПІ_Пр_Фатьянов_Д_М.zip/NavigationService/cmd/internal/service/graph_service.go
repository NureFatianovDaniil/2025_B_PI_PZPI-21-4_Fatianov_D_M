package service

import "github.com/FatiaGlacier/navigation-service/cmd/internal/repository"

type GraphService struct {
	graphRepository *repository.GraphRepository
	edgeRepository  *repository.EdgeRepository
	nodeRepository  *repository.NodeRepository
}

func NewGraphService(
	graphRepository *repository.GraphRepository,
	edgeRepository *repository.EdgeRepository,
	nodeRepository *repository.NodeRepository) *GraphService {
	return &GraphService{
		graphRepository: graphRepository,
		edgeRepository:  edgeRepository,
		nodeRepository:  nodeRepository,
	}
}
