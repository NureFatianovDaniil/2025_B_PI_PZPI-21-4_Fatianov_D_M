package dto

type ZoneModel struct {
	ID            int64       `json:"id"`
	Type          string      `json:"type"`
	OriginX       int         `json:"originX"`
	OriginY       int         `json:"originY"`
	Width         int         `json:"width"`
	Length        int         `json:"length"`
	RotationAngle int         `json:"rotationAngle"` // 0, 90, 180, 270
	FaceDirection int         `json:"faceDirection"` // 0=up, 90=right, 180=down, 270=left
	ChildZones    []ZoneModel `json:"childZones"`
}
