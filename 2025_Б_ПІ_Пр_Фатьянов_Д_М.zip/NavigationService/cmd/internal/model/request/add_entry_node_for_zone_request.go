package request

type AddEntryNodeForZoneRequest struct {
}
