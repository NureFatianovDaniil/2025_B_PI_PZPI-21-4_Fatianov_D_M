package router

import (
	"github.com/FatiaGlacier/navigation-service/cmd/internal/api"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(
	router *gin.Engine,
	nodeHandler *api.NodeHandler,
	edgeHandler *api.EdgeHandler,
	graphHandler *api.GraphHandler) {
	nodeGroup := router.Group("/api/v1/node")
	{
		nodeGroup.GET("/get-all", nodeHandler.GetAllNodes)
		nodeGroup.GET("/get-node/:id", nodeHandler.GetNodeByID)
		nodeGroup.POST("/add-node", nodeHandler.AddNode)
		nodeGroup.POST("/create-entry-from-zone", nodeHandler.CreateEntryNodeFromZone)
		nodeGroup.POST("/connect-nodes/:fromId/:toId", nodeHandler.ConnectNodes)
		nodeGroup.PUT("/update-node/:id", nodeHandler.UpdateNode)
		nodeGroup.DELETE("/delete-node/:id", nodeHandler.DeleteNode)
	}

	edgeGroup := router.Group("/api/v1/edge")
	{
		edgeGroup.GET("/get-all", edgeHandler.GetAllEdges)
		edgeGroup.GET("/get-edge/:id", edgeHandler.GetEdgeByID)
		edgeGroup.POST("/add-edge", edgeHandler.AddEdge)
		edgeGroup.PUT("/update-edge/:id", edgeHandler.UpdateEdge)
		edgeGroup.DELETE("/delete-edge/:id", edgeHandler.DeleteEdge)
	}

	graphGroup := router.Group("/api/v1/graph")
	{
		graphGroup.POST("/update", graphHandler.UpdateGraph)
		graphGroup.POST("/route/waveless", graphHandler.GetRouteWaveless)
		graphGroup.POST("/route/wavebased", graphHandler.GetRouteWavebased)
	}
}
